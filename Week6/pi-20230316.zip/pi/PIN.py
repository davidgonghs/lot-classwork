class PIN():
    SetMode = "None" #IN/OUT/NONE
    Out = "0"
    pull_up_down = "PUD_OFF" #PUD_UP/PUD_DOWN/PUD_OFF
    In = "1"

    def __init__(self, SetMode):
        self.SetMode = SetMode
        self.Out = "0"
        


        
    
    
